<link href="<?php echo osc_base_url() . 'oc-content/plugins/gdpr_cookie_compliance/rackons_cookie.css';?>" rel=stylesheet>
<link href=<?php echo osc_base_url() . 'oc-content/plugins/gdpr_cookie_compliance/gdpr-cookie.css';?> rel=stylesheet>

<script src="https://code.jquery.com/jquery-3.3.1.min.js" crossorigin="anonymous"></script>
<script src="<?php echo osc_base_url() . 'oc-content/plugins/gdpr_cookie_compliance/gdpr-cookie.js';?>"></script>
<script>
    $.gdprcookie.init({
        title: "Accept cookies & privacy policy?",
        message: "<?php echo $gdpr; ?> <a href='<?php echo $policy_url; ?>'>Privacy Policy</a>, <a href='<?php echo $terms_url; ?>'>Terms And Conditions</a>",
        delay: 600,
        expires: 1,
        acceptBtnLabel: "Accept cookies",
    });

    $(document.body)
        .on("gdpr:show", function() {
            console.log("Cookie dialog is shown");
        })
        .on("gdpr:accept", function() {
            var preferences = $.gdprcookie.preference();
            console.log("Preferences saved:", preferences);
        })
        .on("gdpr:advanced", function() {
            console.log("Advanced button was pressed");
        });

    if ($.gdprcookie.preference("marketing") === true) {
        console.log("This should run because marketing is accepted.");
    }
</script>