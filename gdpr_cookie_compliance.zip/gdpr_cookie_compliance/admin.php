 <style>


.rackons-box .rackons-inside .rackons-points .rackons-row {margin:1px 0;}
.rackons-box .rackons-inside input[type="file"] {margin:30px 0 40px 0;}
.flashmessage {min-height:0!important;}


/* HEAD */
.rackons-head {padding:25px 45px 25px 45px;background:#fff;border-bottom:1px solid #DFDFDF;}
.rackons-head h1 {font-family: "Open Sans",Helvetica,Arial,sans-serif;font-size:26px;color:#363A41;display:inline-block;width:100%;padding:0;margin:0;font-weight:bold;}
.rackons-head h2 {font-family: "Open Sans",Helvetica,Arial,sans-serif;font-size:13px;color:#363A41;display:inline-block;width:100%;padding:0;margin:0;font-weight:500;}
.rackons-head-left {display:inline-block;width:35%;}
.rackons-head-right {display:inline-block;width:65%;text-align:right;}
.rackons-head ul.rackons-menu {margin:0 0 -15px 0;padding:0;font-size:12px;width:auto;float:right;display:block;}
.rackons-head ul.rackons-menu li {float:left;margin:0 5px 5px 5px;height:60px;}
.rackons-head ul.rackons-menu li a {text-decoration:none;padding:5px 8px;display:block;font-weight:500;}
.rackons-head ul.rackons-menu li a:hover {text-decoration:none;}
.rackons-head ul.rackons-menu li a i {font-size:26px;width:32px;text-align:center;display:block;height:32px;margin:0 auto;color:#2eacce;text-decoration:none;}
.rackons-head ul.rackons-menu li a:hover i {color:#40c9ed;text-decoration:none;}
.rackons-head ul.rackons-menu li a span {color:#000;text-decoration:none;display:inline-block;text-align:center;max-width:100px;}
.rackons-head ul.rackons-menu li a:hover span {text-decoration:underline;}

/* BODY & BOX */
.rackons-body {display:inline-block;width:95%;padding:20px 10px;}
.rackons-box {position: relative; padding: 5px; margin-bottom: 20px; border: solid 1px #d3d8db; background-color: #fff; -webkit-border-radius: 5px; border-radius: 5px;}
.rackons-box:last-child {margin-bottom:10px;}
.rackons-box .rackons-head {font-weight:500; font-size: 13px;text-transform:uppercase;text-overflow: ellipsis; white-space: nowrap; color: #444; height: 32px;padding:5px 15px;margin:0;line-height:18px;letter-spacing: -0.5px;}
.rackons-box .rackons-head i {margin-right:2px;line-height:18px;display:inline-block;}
.rackons-box .rackons-head a {color:#2EACCE;text-decoration:none;margin:0 5px;text-transform:none;float:right;}
.rackons-box .rackons-head a:hover {color:#333;}
.rackons-box .rackons-head a:after {content:"/";margin-left:10px;color:#555;}
.rackons-box .rackons-head a.rackons-first:after {display:none;}
.rackons-box .rackons-inside {padding:15px;display:inline-block;width:100%;font-size:13px;line-height:18px;}
.rackons-box .rackons-inside .rackons-row {width:100%;display:inline-block;margin:6px 0;clear:both;}
.rackons-box label {width:25%;text-align:right;padding-right:15px;float:left;line-height:31px;}

/* Select, Input, Textarea */
.rackons-box .select-box {height:31px;}
.rackons-box select {opacity:1!important;position:relative;top:auto;left:auto;display:block;-webkit-appearance:menulist!important;min-width:160px;}
.rackons-box .select-box .select-box-trigger, .rackons-box .select-box a {display:none!important;}
.rackons-box input[type="text"], .rackons-box input[type="search"], .rackons-box input[type="password"], .rackons-box textarea, .rackons-box select { float:left;display: block;outline:none; width: auto; height: 31px; padding: 6px 8px; font-size: 12px; line-height: 15px; color: #555; background-color: #FFF0F5; background-image: none; border: 1px solid #FFDEAD; border-radius: 3px; -webkit-transition: border-color ease-in-out 0.15s,box-shadow ease-in-out 0.15s; -o-transition: border-color ease-in-out 0.15s,box-shadow ease-in-out 0.15s; transition: border-color ease-in-out 0.15s,box-shadow ease-in-out 0.15s;box-shadow:none;-webkit-box-shadow:none; }
.rackons-box input[type="text"]:focus, .rackons-box input[type="search"]:focus, .rackons-box input[type="password"]:focus, .rackons-box textarea:focus, .rackons-box select:focus {background-color:#FFF0F5;border-color:#FFDEAD;}
.rackons-box textarea {min-width:30%;max-width:30%;height:80px;}
.rackons-box span.sup {font-weight:bold;}
.rackons-box > .rackons-inside > .rackons-row.rackons-help > div, .rackons-box > .rackons-inside > .rackons-row.rackons-help > span {display:inline;padding:0 4px;}
.rackons-box .rackons-foot {width:95%;display:inline-block;padding:10px 15px;border-top:1px solid #DFDFDF;text-align:left;background:#fcfcfc;}
.rackons-box .rackons-input-desc {display:inline-block;height:31px;position:relative;z-index:2;margin-left:-3px;padding: 6px 8px; font-size: 12px; font-weight: normal; line-height: 15px; color: #555; text-align: center; background-color: #F5F8F9; border-top: 1px solid #C7D6DB; border-left: 1px solid #C7D6DB; border-bottom: 1px solid #C7D6DB; border-right: 1px solid #C7D6DB;-webkit-border-top-right-radius: 3px; -webkit-border-bottom-right-radius: 3px; -moz-border-radius-topright: 3px; -moz-border-radius-bottomright: 3px; border-top-right-radius: 3px; border-bottom-right-radius: 3px;}
.rackons-box .rackons-help-highlight {color: #3586AE; background-color: #edf7fb; border: none; border-bottom: solid 1px #D8EDF7; padding: 0 4px; -webkit-border-radius: 3px; border-radius: 3px;}
.rackons-box .rackons-explain {width:75%;display:inline-block;margin-left:25%;clear:both;margin-top: 5px; margin-bottom: 10px; color: #959595;font-style:italic;font-size:12px;}

/* Button */
.rackons-box .rackons-foot .rackons-button {color: #363A41; background-color: #fff;outline:none; border:1px solid #DEDEDE;display: inline-block; margin-bottom: 0; font-weight: normal; text-align: center; vertical-align: middle; cursor: pointer; background-image: none; white-space: nowrap; padding: 2px 10px 5px 10px; font-size: 12px; line-height: 1.42857; border-radius: 3px; -webkit-user-select: none; -moz-user-select: none; -ms-user-select: none; user-select: none;}
.rackons-box .rackons-foot .rackons-button:before {content:"\f0c7";font-family:"FontAwesome";display: block; width: 30px; height: 30px; margin: 0 auto 3px auto; font-size: 28px; background: transparent; background-size: 26px; background-position: center;}
.rackons-box .rackons-foot .rackons-button:hover {color: #c8232c; background-color: #f8e6e7; border-color: #c8232c; -webkit-box-shadow: none; box-shadow: none;}




</style>	

<?php $pluginInfo = osc_plugin_get_info('gdpr_cookie_compliance/index.php'); ?>
<div class="rackons-box">
    <div class="rackons-head"><i class="fa fa-cog"></i> <?php _e('GDPR Cookie Compliance', 'gdpr_cookie_compliance'); ?></div>
<br>
    <div class="rackons-inside">
        
<form action="<?php echo osc_admin_render_plugin_url('gdpr_cookie_compliance/admin.php'); ?>" method="post">
  <input type="hidden" name="option" value="gdprcookie" />
  <fieldset>
    <legend>
      <h1><?php _e('Configure GDPR Cookie Compliance plugin', 'gdpr_cookie_compliance'); ?></h1><br>
    </legend>
    <div class="form-horizontal">

<div class="rackons-row">
        <label><?php _e('GDPR Cookie Paragraph', 'gdpr_cookie_compliance') ?> <a href="#1"><span class="hasTooltip" title="In this paragraph you can edit or not GDPR Policy Sentence for your Users and Visitors"> <i class="fa fa-question-circle"></i></span></a> : </label>
       
           <textarea name="gdpr"> <?php echo osc_esc_html(osc_gdpr()); ?></textarea>
 
      </div>

 <div class="rackons-row">
        <label><?php _e('Privacy Policy URL', 'gdpr_cookie_compliance') ?><a href="#3"><span class="hasTooltip" title="Put Your Privacy Policy URL"> <i class="fa fa-question-circle"></i></span></a> : </label>
            <input size="48" type="text" class="xlarge" name="policy_url" value="<?php echo osc_esc_html(osc_policy_url()); ?>">

      </div>
      
<div class="rackons-row">
   <label><?php _e('Terms and Condition URL', 'gdpr_cookie_compliance') ?><a href="#5"><span class="hasTooltip" title="Put your Terms and Conditions URL"> <i class="fa fa-question-circle"></i></span></a> : </label>

<input size="48" type="text" class="xlarge" name="terms_url" value="<?php echo osc_esc_html(osc_terms_url()); ?>">
      </div>  


      <div class="rackons-foot">
          <button type="submit" class="rackons-button"><?php _e('Save', 'gdpr_cookie_compliance');?></button>
      </div>
        
    </div>
  </fieldset>
</form>
<div class="rackons-body">
 <!-- HELP TOPICS -->
  <div class="rackons-box" id="rackons-help">
    <div class="rackons-head"><i class="fa fa-question-circle"></i> <?php _e('Help', 'gdpr_cookie_compliance'); ?></div>

    <div class="rackons-inside">
      <div class="rackons-row rackons-help"><h2>GDPR Cookies Compliance Plugin</h2> </div>
      GDPR plugin for cookie policies that displays a GDPR Cookie Consent Notice popup to helps you comply with General Data Protection Regulation (GDPR).
      Click the Customize Cookies to display several options with checkboxes that enable the visitors to opt-in and opt-out of the various types of cookies: Analytics, Essential, Marketing, Site Preferences.
      
      After Installing this plugin, it will automatically run on website, you dont need to put any code

</div>


      


    </div>
  </div>
</div>
</div>

<address class="rac_copy">
	<span>&copy; <?php echo date('Y'); ?> <a target="_blank" title="GDPR Cookie Compliance Plugin" href="http://rackons.com/">Rackons.com</a>. All rights reserved <a href="https://osclassmarket.rackons.in/">Rackons Market</a> | <a href="https://forums.rackons.in/">Rackons Forums</a> . <a href="https://tawk.to/3e48c07c1201283dfa843bcde67a37e1b8adad17" target="_blank">Rackons Live Chat Support</a></span>
</address>