<?php
/*
  Plugin Name:GDPR Cookie Compliance Plugin
  Plugin URI: https://osclassmarket.rackons.in/
  Description: GDPR plugin for cookie policies that displays a GDPR Cookie Consent Notice popup to helps you comply with General Data Protection Regulation (GDPR).
  Version: 1.2.1
  Author: Rackons Market
  Author URI: https://osclassmarket.rackons.in/
  Author Email: info@rackons.in
  Short Name: gdpr_cookie_compliance
 */

function gdpr_cookie_compliance_call_after_install() {
  osc_set_preference('gdpr', 'At our website, we have changed our Privacy Policy and Terms of Use in order to adapt them to the new General Data Protection Regulation (GDPR). As the GDPR comes into force, legislation requires us that you grant us permission to store cookies in your browser. Remember you can find more information about what we do with your data by', 'gdpr_cookie_compliance', 'STRING');
 osc_set_preference('policy_url', 'http://rackons.com/privacy-p31', 'gdpr_cookie_compliance', 'STRING');
  osc_set_preference('terms_url', 'http://rackons.com/terms-p30', 'gdpr_cookie_compliance', 'STRING');  

 
}

function gdpr_cookie_compliance_call_after_uninstall() {
 osc_delete_preference('gdpr', 'gdpr_cookie_compliance');
 osc_delete_preference('policy_url', 'gdpr_cookie_compliance');
  osc_delete_preference('terms_url', 'gdpr_cookie_compliance'); 
}

function gdpr_cookie_compliance_actions() {
  $dao_preference = new Preference();
  $option = Params::getParam('option');

  if (Params::getParam('file') != 'gdpr_cookie_compliance/admin.php') {
    return '';
  }

  if ($option == 'gdprcookie') {
   osc_set_preference('gdpr', Params::getParam("gdpr") ? Params::getParam("gdpr") : '0', 'gdpr_cookie_compliance', 'STRING');
osc_set_preference('policy_url', Params::getParam("policy_url") ? Params::getParam("policy_url") : '0', 'gdpr_cookie_compliance', 'STRING');
    osc_set_preference('terms_url', Params::getParam("terms_url") ? Params::getParam("terms_url") : '0', 'gdpr_cookie_compliance', 'STRING');    
 
    osc_add_flash_ok_message(__('The GDPR Cookie Compliance plugin has been updated', 'gdpr_cookie_compliance'), 'admin');
    osc_redirect_to(osc_admin_render_plugin_url('gdpr_cookie_compliance/admin.php'));
  }
}

// HELPER

function osc_gdpr() {
  return(osc_get_preference('gdpr', 'gdpr_cookie_compliance'));
}

function osc_policy_url() {
  return(osc_get_preference('policy_url', 'gdpr_cookie_compliance'));
}

function osc_terms_url() {
  return(osc_get_preference('terms_url', 'gdpr_cookie_compliance'));
}
function gdpr_cookie_compliance_admin() {
  osc_admin_render_plugin('gdpr_cookie_compliance/admin.php');
}

/**
 * Create a menu on the admin panel
 */
function gdpr_cookie_compliance_admin_menu() {
  
    osc_add_admin_submenu_divider('plugins', 'GDOR Cookie Compliance Plugin', 'gdpr_cookie_compliance', 'administrator');
    osc_add_admin_submenu_page('plugins', __('Settings', 'gdpr_cookie_compliance'), osc_route_admin_url('gdpr-cookie-compliance-admin-conf'), 'gdpr_cookie_compliance_settings', 'administrator');
}


/**
 * This function is called every time the page header is being rendered 
 */
function gdpr_cookie_compliance() {
  $gdpr = osc_gdpr();
 $policy_url = osc_policy_url();
  $terms_url = osc_terms_url(); 
   
    require_once(osc_plugins_path() . 'gdpr_cookie_compliance/code.php');
  
}

osc_add_hook('header', 'gdpr_cookie_compliance');


osc_add_route('gdpr-cookie-compliance-admin-conf', 'gdpr_cookie_compliance', 'gdpr_cookie_compliance', osc_plugin_folder(__FILE__).'admin.php');

osc_add_hook('init_admin', 'gdpr_cookie_compliance_actions');

// show menu items
osc_add_hook('admin_menu_init', 'gdpr_cookie_compliance_admin_menu');

// This is a hack to show a Uninstall link at plugins table (you could also use some other hook to show a custom option panel)
osc_add_hook(osc_plugin_path(__FILE__) . "_uninstall", 'gdpr_cookie_compliance_call_after_uninstall');
osc_add_hook(osc_plugin_path(__FILE__) . "_configure", 'gdpr_cookie_compliance_admin');


// This is needed in order to be able to activate the plugin
osc_register_plugin(osc_plugin_path(__FILE__), 'gdpr_cookie_compliance_call_after_install');
?>